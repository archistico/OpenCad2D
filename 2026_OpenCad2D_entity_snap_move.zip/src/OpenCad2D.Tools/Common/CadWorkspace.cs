using OpenCad2D.Core.Commands;
using OpenCad2D.Core.Documents;
using OpenCad2D.Core.Entities;
using OpenCad2D.Core.Identifiers;
using OpenCad2D.Geometry;
using OpenCad2D.Geometry.Coordinates;
using OpenCad2D.Geometry.Primitives;
using OpenCad2D.Interaction.Selection;
using OpenCad2D.Interaction.Snapping;
using OpenCad2D.Tools.Grips;
using OpenCad2D.Tools.Selection;
using OpenCad2D.Core.Layers;

namespace OpenCad2D.Tools.Common;

/// <summary>
/// Aggregates the main CAD runtime services used by the application.
/// </summary>
public sealed class CadWorkspace
{
    private int _savedGeneration;

    public CadWorkspace(
        CadDocument? document = null,
        CommandHistory? commandHistory = null,
        SelectionSet? selectionSet = null,
        SnapService? snapService = null,
        SelectionService? selectionService = null,
        ToolRegistry? toolRegistry = null,
        GridSettings? gridSettings = null,
        LayerId? currentLayerId = null,
        SnapKind enabledSnaps = SnapKind.None,
        double snapTolerance = 0,
        double selectionTolerance = 5,
        double selectionDragThreshold = 1,
        ToolId initialToolId = ToolId.Selection,
        CoordinateSystem2D? currentUcs = null,
        GeometryTolerance? geometryTolerance = null)
    {
        Document = document ?? new CadDocument();
        CommandHistory = commandHistory ?? new CommandHistory();
        SelectionSet = selectionSet ?? new SelectionSet();
        SnapService = snapService ?? new SnapService();
        SelectionService = selectionService ?? new SelectionService();
        ToolRegistry = toolRegistry ?? new ToolRegistry();
        GridSettings = gridSettings ?? new GridSettings();
        GripProviders = new GripProviderRegistry();

        Context = new ToolContext(
            Document,
            CommandHistory,
            SnapService,
            selectionSet: SelectionSet,
            selectionService: SelectionService,
            gridSettings: GridSettings,
            currentLayerId: currentLayerId ?? LayerId.Default,
            enabledSnaps: enabledSnaps,
            snapTolerance: snapTolerance,
            selectionTolerance: selectionTolerance,
            selectionDragThreshold: selectionDragThreshold,
            currentUcs: currentUcs,
            geometryTolerance: geometryTolerance);

        ToolController = new ToolController(
            Context,
            ToolRegistry.Create(initialToolId));

        ActionController = new CadActionController(
            Context,
            ToolController);

        MarkSaved();
    }

    public CadDocument Document { get; private set; }

    public CommandHistory CommandHistory { get; }

    public SelectionSet SelectionSet { get; }

    public SnapService SnapService { get; }

    public SelectionService SelectionService { get; }

    public ToolRegistry ToolRegistry { get; }

    public GridSettings GridSettings { get; private set; }

    public GripProviderRegistry GripProviders { get; }

    public ToolContext Context { get; }

    public ToolController ToolController { get; }

    public CadActionController ActionController { get; }

    public bool IsDirty => CommandHistory.CurrentGeneration != _savedGeneration;

    public LayerId CurrentLayerId
    {
        get => Context.CurrentLayerId;
        set => Context.CurrentLayerId = value;
    }

    public CoordinateSystem2D CurrentUcs
    {
        get => Context.CurrentUcs;
        set => Context.CurrentUcs = value;
    }

    public GeometryTolerance GeometryTolerance
    {
        get => Context.GeometryTolerance;
        set => Context.GeometryTolerance = value;
    }


    public void MarkSaved()
    {
        _savedGeneration = CommandHistory.CurrentGeneration;
    }

    public void MarkDocumentChanged()
    {
        CommandHistory.RegisterExternalChange();
    }

    public void LoadDocument(
        CadDocument document,
        LayerId currentLayerId)
    {
        ArgumentNullException.ThrowIfNull(document);

        Document = document;
        Context.Document = document;

        CommandHistory.Clear();
        SelectionSet.Clear();
        Context.CurrentBasePoint = null;

        CurrentLayerId = document.Layers.Contains(currentLayerId)
            ? currentLayerId
            : LayerId.Default;

        ToolController.SetActiveToolWithoutDeactivating(
            new SelectionTool());

        MarkSaved();
    }

    public void NewDocument()
    {
        LoadDocument(
            new CadDocument(),
            LayerId.Default);
    }

    public ToolResult SetGridSettings(GridSettings gridSettings)
    {
        ArgumentNullException.ThrowIfNull(gridSettings);

        GridSettings = gridSettings;
        Context.Snapping.GridSettings = gridSettings;

        return ToolResult.Updated("Grid settings updated.");
    }

    public ToolResult SetGridVisible(bool isVisible)
    {
        return SetGridSettings(GridSettings.WithVisibility(isVisible));
    }

    public ToolResult SetActiveTool(ToolId toolId)
    {
        ICadTool tool = ToolRegistry.Create(toolId);

        return ToolController.SetActiveTool(tool);
    }

    public ToolResult SetActiveToolWithoutDeactivating(ToolId toolId)
    {
        ICadTool tool = ToolRegistry.Create(toolId);

        return ToolController.SetActiveToolWithoutDeactivating(tool);
    }

    public ToolResult SubmitPointFromCommandLine(Point2D worldPoint)
    {
        var pointer = new PointerInfo(
            worldPoint,
            CurrentUcs.WorldToUser(worldPoint));

        bool originalOrthoState = Context.IsOrthoEnabled;

        try
        {
            // Command-line points have already been resolved explicitly by the caller.
            // In particular, direct distance entry applies Ortho while calculating
            // the final point, while absolute and relative coordinates must remain exact.
            Context.IsOrthoEnabled = false;

            return ToolController.OnPointerPressed(pointer);
        }
        finally
        {
            Context.IsOrthoEnabled = originalOrthoState;
        }
    }


    public ToolResult EnterGripEditModeForSelection()
    {
        EntityId? entityId = SelectionSet.LastSelectedId;

        if (entityId is null)
        {
            return ToolResult.None("No selected entity for grip edit.");
        }

        return EnterGripEditMode(entityId.Value);
    }

    public ToolResult EnterGripEditMode(EntityId entityId)
    {
        if (!Document.Entities.TryGet(entityId, out CadEntity? entity) ||
            entity is null)
        {
            return ToolResult.None("Cannot enter grip edit mode because the entity was not found.");
        }

        if (!Document.IsEntitySelectable(entity))
        {
            return ToolResult.None("Cannot enter grip edit mode because the entity is not selectable.");
        }

        if (GripProviders.FindProvider(entity) is null)
        {
            return ToolResult.None("Selected entity does not support grip editing.");
        }

        var gripEditTool = new GripEditTool(
            entityId,
            GripProviders);

        ToolResult activationResult = gripEditTool.Activate(Context);

        if (gripEditTool.ShouldExit)
        {
            return activationResult;
        }

        ToolController.SetActiveToolWithoutDeactivating(gripEditTool);

        return activationResult.Changed
            ? activationResult
            : ToolResult.Started("Grip edit started.");
    }

    public ToolResult ExitGripEditMode()
    {
        return ToolController.SetActiveToolWithoutDeactivating(
            new SelectionTool());
    }


    public ToolResult ApplyLayerChanges(
        IEnumerable<Layer> layers,
        LayerId currentLayerId)
    {
        ArgumentNullException.ThrowIfNull(layers);

        List<Layer> layerList = layers.ToList();

        if (layerList.Count == 0)
        {
            return ToolResult.None("Layer manager requires at least one layer.");
        }

        Layer? currentLayer = layerList.FirstOrDefault(layer => layer.Id == currentLayerId);

        if (currentLayer is null)
        {
            return ToolResult.None("The current layer does not exist.");
        }

        if (!currentLayer.IsVisible || currentLayer.IsLocked)
        {
            return ToolResult.None("The current layer must be visible and unlocked.");
        }

        var command = new UpdateLayersCommand(
            Document.Layers.All.ToList(),
            layerList);

        CommandHistory.Execute(
            Document,
            command);

        CurrentLayerId = currentLayerId;

        int removedSelections = ClearSelectionOfNonSelectableEntities();

        string message = "Layers updated.";

        if (removedSelections > 0)
        {
            message += $" {removedSelections} selected entity/entities removed from selection.";
        }

        return ToolResult.Completed(message);
    }

    public void EnsureCurrentLayerIsUsable()
    {
        if (!Document.Layers.Contains(CurrentLayerId))
        {
            CurrentLayerId = LayerId.Default;
        }

        Layer currentLayer = Document.Layers.GetRequired(CurrentLayerId);

        if (currentLayer.IsVisible && !currentLayer.IsLocked)
        {
            return;
        }

        Layer? firstUsableLayer = Document.Layers.All
            .OrderBy(layer => layer.Name)
            .FirstOrDefault(layer => layer.IsVisible && !layer.IsLocked);

        CurrentLayerId = firstUsableLayer?.Id ?? LayerId.Default;
    }

    public ToolResult SetCurrentLayerLocked(bool isLocked)
    {
        Document.Layers.SetLocked(
            CurrentLayerId,
            isLocked);

        int removedSelections = ClearSelectionOfNonSelectableEntities();

        string message = isLocked
            ? "Current layer locked."
            : "Current layer unlocked.";

        if (removedSelections > 0)
        {
            message += $" {removedSelections} selected entity/entities removed from selection.";
        }

        return ToolResult.Completed(message);
    }

    public int ClearSelectionOfNonSelectableEntities()
    {
        int removed = 0;

        foreach (EntityId entityId in SelectionSet.SelectedIds.ToList())
        {
            if (!Document.Entities.Contains(entityId))
            {
                SelectionSet.Deselect(entityId);
                removed++;
                continue;
            }

            CadEntity entity = Document.Entities.GetRequired(entityId);

            if (Document.IsEntitySelectable(entity))
            {
                continue;
            }

            SelectionSet.Deselect(entityId);
            removed++;
        }

        return removed;
    }

    public ToolResult Escape()
    {
        if (ToolController.ActiveTool is GripEditTool gripEditTool)
        {
            ToolResult gripCancelResult = gripEditTool.Cancel(Context);

            if (gripEditTool.ShouldExit)
            {
                ExitGripEditMode();

                return ToolResult.Cancelled("Grip edit exited.");
            }

            return gripCancelResult;
        }

        ToolResult cancelResult = ActionController.CancelActiveTool();

        if (cancelResult.Changed)
        {
            return cancelResult;
        }

        if (!SelectionSet.IsEmpty)
        {
            SelectionSet.Clear();

            return ToolResult.Updated("Selection cleared.");
        }

        return ToolResult.None("Nothing to cancel.");
    }
}
