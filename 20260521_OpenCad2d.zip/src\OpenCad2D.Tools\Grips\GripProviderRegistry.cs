﻿using OpenCad2D.Core.Entities;

namespace OpenCad2D.Tools.Grips;

/// <summary>
/// Resolves the grip provider that supports a given CAD entity.
/// </summary>
public sealed class GripProviderRegistry
{
    private readonly List<IGripProvider> _providers = new();

    public GripProviderRegistry()
    {
        Register(new PointGripProvider());
        Register(new TextGripProvider());
        Register(new MultilineTextGripProvider());
        Register(new LineGripProvider());
        Register(new CircleGripProvider());
        Register(new EllipseGripProvider());
        Register(new ArcGripProvider());
        Register(new PolylineGripProvider());
        Register(new BezierSplineGripProvider());
    }

    public IReadOnlyList<IGripProvider> Providers => _providers;

    public void Register(IGripProvider provider)
    {
        ArgumentNullException.ThrowIfNull(provider);

        _providers.Add(provider);
    }

    public IGripProvider? FindProvider(CadEntity entity)
    {
        ArgumentNullException.ThrowIfNull(entity);

        return _providers.FirstOrDefault(provider => provider.CanHandle(entity));
    }
}
