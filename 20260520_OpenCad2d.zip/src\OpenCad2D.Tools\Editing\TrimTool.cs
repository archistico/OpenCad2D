using OpenCad2D.Core.Commands;
using OpenCad2D.Core.Editing;
using OpenCad2D.Core.Entities;
using OpenCad2D.Core.Identifiers;
using OpenCad2D.Geometry;
using OpenCad2D.Geometry.Primitives;
using OpenCad2D.Interaction.Snapping;
using OpenCad2D.Tools.Common;
using OpenCad2D.Tools.Input;

namespace OpenCad2D.Tools.Editing;

/// <summary>
/// Trims editable entities against a selected boundary entity.
/// </summary>
public sealed class TrimTool : ICadTool, ISnapModeProvider, ICommandDrivenTool, IToolPreviewDescriptorProvider
{
    private readonly List<CadEntity> _boundaryEntities = new();
    private EntityId? _boundaryEntityId;
    private EntityId? _secondBoundaryEntityId;
    private CadEntity? _boundaryEntity;
    private IReadOnlyList<CadEntity> _previewEntities = Array.Empty<CadEntity>();
    private IReadOnlyList<CadEntity> _highlightPreviewEntities = Array.Empty<CadEntity>();
    private int _trimOperationsExecuted;
    private bool _usesAllVisibleCuttingEdges;

    public string Name => "Trim";

    public TrimToolState State { get; private set; } =
        TrimToolState.WaitingForBoundaryEntity;

    public EntityId? BoundaryEntityId => _boundaryEntityId;

    /// <summary>
    /// Gets the optional second cutting edge selected with Ctrl-click.
    /// </summary>
    public EntityId? SecondBoundaryEntityId => _secondBoundaryEntityId;

    public bool HasPreview =>
        State == TrimToolState.WaitingForTargetEntity &&
        _previewEntities.Count > 0;


    public SnapKind GetActiveSnapKind(ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        return SnapKind.EntityOnly;
    }


    public CommandPromptState GetPromptState(ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        return State switch
        {
            TrimToolState.WaitingForBoundaryEntity => new CommandPromptState(
                "TRIM",
                "Select cutting edge",
                CommandInputKind.SelectionOrOption,
                new[]
                {
                    new CommandOption("All", "A", "Use all visible supported entities as cutting edges")
                },
                placeholder: "Click a cutting edge or type All"),

            TrimToolState.WaitingForTargetEntity => new CommandPromptState(
                "TRIM",
                "Select entity side to trim",
                CommandInputKind.SelectionOrOption,
                new[]
                {
                    new CommandOption("All", "A", "Use all visible supported entities as cutting edges"),
                    new CommandOption("Undo", "U", "Undo the last trim made by this command")
                },
                acceptsEmptyEnter: true,
                placeholder: "Click side to remove, Ctrl-click to add cutting edge, U to undo"),

            _ => CommandPromptState.Idle
        };
    }

    public ToolResult HandleCommandInput(
        CommandInputSubmission input,
        ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(input);
        ArgumentNullException.ThrowIfNull(context);

        if (input.Kind == CommandInputSubmissionKind.Option &&
            string.Equals(input.OptionKeyword, "All", StringComparison.OrdinalIgnoreCase))
        {
            return UseAllVisibleCuttingEdges(context);
        }

        if (State == TrimToolState.WaitingForTargetEntity &&
            input.Kind == CommandInputSubmissionKind.Option &&
            string.Equals(input.OptionKeyword, "Undo", StringComparison.OrdinalIgnoreCase))
        {
            return UndoLastTrim(context);
        }

        if (State == TrimToolState.WaitingForTargetEntity &&
            input.Kind == CommandInputSubmissionKind.Confirm)
        {
            Reset(context);
            return ToolResult.Completed("Trim command finished.");
        }

        return State == TrimToolState.WaitingForBoundaryEntity
            ? ToolResult.None("Select a cutting edge from the drawing canvas or type All.")
            : ToolResult.None("Select an entity side to trim from the drawing canvas, Ctrl-click to add cutting edges, or type Undo.");
    }

    public ToolResult OnPointerPressed(
        ToolContext context,
        PointerInfo pointer)
    {
        ArgumentNullException.ThrowIfNull(context);
        ArgumentNullException.ThrowIfNull(pointer);

        return State switch
        {
            TrimToolState.WaitingForBoundaryEntity =>
                AcceptBoundaryEntity(context, pointer),

            TrimToolState.WaitingForTargetEntity =>
                AcceptTargetEntity(context, pointer),

            _ => ToolResult.None()
        };
    }

    public ToolResult OnPointerMoved(
        ToolContext context,
        PointerInfo pointer)
    {
        ArgumentNullException.ThrowIfNull(context);
        ArgumentNullException.ThrowIfNull(pointer);

        if (State != TrimToolState.WaitingForTargetEntity ||
            _boundaryEntities.Count == 0)
        {
            return ToolResult.None();
        }

        UpdatePreview(context, pointer.ModelPoint);

        return HasPreview
            ? ToolResult.Updated("Trim preview updated.")
            : ToolResult.None("Select an entity part that can be trimmed by the boundary.");
    }

    public ToolResult Cancel(ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        Reset(context);

        return ToolResult.Cancelled("Trim command cancelled.");
    }

    public ToolResult Deactivate(ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        Reset(context);

        return ToolResult.None("Trim tool deactivated.");
    }

    public IReadOnlyList<CadEntity> GetPreviewEntities()
    {
        return _previewEntities.ToList();
    }

    /// <summary>
    /// Gets the entities that represent the portion that will be removed by the current trim preview.
    /// </summary>
    public IReadOnlyList<CadEntity> GetHighlightedPreviewEntities()
    {
        return _highlightPreviewEntities.ToList();
    }


    public ToolPreviewDescriptor GetPreviewDescriptor(ToolContext context)
    {
        ArgumentNullException.ThrowIfNull(context);

        return new ToolPreviewDescriptor(
            entities: GetPreviewEntities(),
            highlightedEntities: GetHighlightedPreviewEntities(),
            highlightedEntityKind: ToolPreviewHighlightKind.Removal);
    }

    private ToolResult AcceptBoundaryEntity(
        ToolContext context,
        PointerInfo pointer)
    {
        EntityId? selectedId = SelectVisibleEntityByPoint(
            context,
            pointer.ModelPoint);

        if (selectedId is null)
        {
            return ToolResult.None("Select a visible boundary entity.");
        }

        CadEntity entity = context.Document.Entities.GetRequired(selectedId.Value);

        if (!IsSupportedEntity(entity))
        {
            return ToolResult.None("Trim supports lines, circles, arcs, ellipses, elliptical arcs, polylines and splines.");
        }

        if (!context.Document.IsEntityVisible(entity))
        {
            return ToolResult.None("Boundary entity is not visible.");
        }

        _boundaryEntityId = entity.Id;
        _boundaryEntity = entity;
        _boundaryEntities.Clear();
        _boundaryEntities.Add(entity);
        _usesAllVisibleCuttingEdges = false;
        _secondBoundaryEntityId = null;
        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        State = TrimToolState.WaitingForTargetEntity;
        context.CurrentBasePoint = entity.GetClosestPoint(pointer.ModelPoint);

        return ToolResult.Started(
            "Select an entity side to trim by the boundary, or Ctrl-click a second cutting edge.");
    }

    private ToolResult AcceptTargetEntity(
        ToolContext context,
        PointerInfo pointer)
    {
        if (_boundaryEntities.Count == 0)
        {
            throw new InvalidOperationException(
                "Cannot trim before selecting a boundary entity.");
        }

        if (pointer.IsControlPressed)
        {
            EntityId? visibleBoundaryId = SelectVisibleEntityByPoint(
                context,
                pointer.ModelPoint);

            if (visibleBoundaryId is null)
            {
                return ToolResult.None("Select a visible second cutting edge.");
            }

            CadEntity visibleBoundary = context.Document.Entities.GetRequired(visibleBoundaryId.Value);

            return AcceptSecondBoundaryEntity(context, visibleBoundary, pointer);
        }

        EntityId? selectedId = SelectEntityByPoint(
            context,
            pointer.ModelPoint);

        if (selectedId is null)
        {
            return ToolResult.None("Select an editable entity to trim.");
        }

        if (!_usesAllVisibleCuttingEdges &&
            _boundaryEntities.Any(boundary => selectedId.Value.Equals(boundary.Id)))
        {
            return ToolResult.None("Target entity must be different from the selected cutting edge.");
        }

        CadEntity entity = context.Document.Entities.GetRequired(selectedId.Value);

        if (!IsSupportedEntity(entity))
        {
            return ToolResult.None("Trim supports lines, circles, arcs, ellipses, elliptical arcs, polylines and splines.");
        }

        if (!context.Document.IsEntitySelectable(entity))
        {
            return ToolResult.None("Target entity is not editable.");
        }

        IReadOnlyList<CadEntity> effectiveBoundaries = GetEffectiveBoundariesForTarget(entity);

        if (effectiveBoundaries.Count == 0)
        {
            return ToolResult.None("No cutting edge is available for the selected target entity.");
        }

        IReadOnlyList<CadEntity> trimmedEntities = CadTrimService.TrimByBoundaries(
            entity,
            effectiveBoundaries,
            pointer.ModelPoint,
            context.GeometryTolerance);

        if (trimmedEntities.Count == 0)
        {
            return ToolResult.None(
                _boundaryEntities.Count > 1
                    ? "The selected entity cannot be trimmed by the selected cutting edges from the picked side."
                    : "The selected entity cannot be trimmed by the boundary from the picked side.");
        }

        context.Commands.Execute(
            context.Document,
            new ModifyEntitiesCommand(
                new[] { entity },
                trimmedEntities,
                "Trim entity"));
        _trimOperationsExecuted++;

        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        context.CurrentBasePoint = entity.GetClosestPoint(pointer.ModelPoint);

        return ToolResult.Completed(
            "Entity trimmed. Select another entity to trim, type Undo, or press Enter/Escape to finish.");
    }

    private ToolResult AcceptSecondBoundaryEntity(
        ToolContext context,
        CadEntity entity,
        PointerInfo pointer)
    {
        if (_boundaryEntities.Any(boundary => boundary.Id.Equals(entity.Id)))
        {
            return ToolResult.None("Cutting edge is already selected.");
        }

        if (!IsSupportedEntity(entity))
        {
            return ToolResult.None("Trim supports lines, circles, arcs, ellipses, elliptical arcs, polylines and splines as cutting edges.");
        }

        if (!context.Document.IsEntityVisible(entity))
        {
            return ToolResult.None("Second cutting edge is not visible.");
        }

        _boundaryEntities.Add(entity);
        _usesAllVisibleCuttingEdges = false;
        _secondBoundaryEntityId = entity.Id;
        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        context.CurrentBasePoint = entity.GetClosestPoint(pointer.ModelPoint);

        return ToolResult.Started(
            $"Cutting edge selected ({_boundaryEntities.Count}). Select the target portion to trim or Ctrl-click another cutting edge.");
    }

    private ToolResult UseAllVisibleCuttingEdges(ToolContext context)
    {
        List<CadEntity> cuttingEdges = context.Document.GetVisibleEntities()
            .Where(IsSupportedEntity)
            .ToList();

        if (cuttingEdges.Count == 0)
        {
            return ToolResult.None("No visible supported cutting edges found.");
        }

        _boundaryEntities.Clear();
        _boundaryEntities.AddRange(cuttingEdges);
        _usesAllVisibleCuttingEdges = true;
        _boundaryEntity = cuttingEdges[0];
        _boundaryEntityId = cuttingEdges[0].Id;
        _secondBoundaryEntityId = cuttingEdges.Count > 1
            ? cuttingEdges[1].Id
            : null;
        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        State = TrimToolState.WaitingForTargetEntity;
        context.CurrentBasePoint = null;

        return ToolResult.Started(
            $"Using all visible supported entities as cutting edges ({cuttingEdges.Count}). Select an entity side to trim.");
    }

    private ToolResult UndoLastTrim(ToolContext context)
    {
        if (_trimOperationsExecuted <= 0)
        {
            return ToolResult.None("No trim operation to undo in the current command.");
        }

        if (!context.Commands.History.CanUndo)
        {
            _trimOperationsExecuted = 0;
            return ToolResult.None("No undoable trim operation is available.");
        }

        context.Commands.History.Undo(context.Document);
        _trimOperationsExecuted--;
        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        context.CurrentBasePoint = null;

        return ToolResult.Updated("Last trim operation undone. Select another entity side to trim.");
    }

    private void UpdatePreview(
        ToolContext context,
        Point2D point)
    {
        if (_boundaryEntity is null)
        {
            _previewEntities = Array.Empty<CadEntity>();
            _highlightPreviewEntities = Array.Empty<CadEntity>();
            return;
        }

        EntityId? selectedId = SelectEntityByPoint(
            context,
            point);

        if (selectedId is null ||
            (!_usesAllVisibleCuttingEdges &&
                _boundaryEntities.Any(boundary => selectedId.Value.Equals(boundary.Id))))
        {
            _previewEntities = Array.Empty<CadEntity>();
            _highlightPreviewEntities = Array.Empty<CadEntity>();
            return;
        }

        CadEntity entity = context.Document.Entities.GetRequired(selectedId.Value);

        if (!IsSupportedEntity(entity) ||
            !context.Document.IsEntitySelectable(entity))
        {
            _previewEntities = Array.Empty<CadEntity>();
            _highlightPreviewEntities = Array.Empty<CadEntity>();
            return;
        }

        IReadOnlyList<CadEntity> effectiveBoundaries = GetEffectiveBoundariesForTarget(entity);

        if (effectiveBoundaries.Count == 0)
        {
            _previewEntities = Array.Empty<CadEntity>();
            _highlightPreviewEntities = Array.Empty<CadEntity>();
            return;
        }

        _previewEntities = CadTrimService.TrimByBoundaries(
            entity,
            effectiveBoundaries,
            point,
            context.GeometryTolerance);
        _highlightPreviewEntities = CadTrimService.GetRemovedIntervalByBoundaries(
            entity,
            effectiveBoundaries,
            point,
            context.GeometryTolerance);
    }


    private IReadOnlyList<CadEntity> GetEffectiveBoundariesForTarget(CadEntity target)
    {
        return _usesAllVisibleCuttingEdges
            ? _boundaryEntities
                .Where(boundary => !boundary.Id.Equals(target.Id))
                .ToList()
            : _boundaryEntities;
    }


    private static IReadOnlyList<CadEntity> CreateTrimHighlightEntities(
        CadEntity target,
        IReadOnlyList<CadEntity> keptEntities,
        GeometryTolerance tolerance)
    {
        if (target is not LineEntity sourceLine)
        {
            return Array.Empty<CadEntity>();
        }

        List<LineEntity> keptLines = keptEntities
            .OfType<LineEntity>()
            .ToList();

        if (keptLines.Count == 0)
        {
            return Array.Empty<CadEntity>();
        }

        if (keptLines.Count == 1)
        {
            LineEntity kept = keptLines[0];

            if (tolerance.ArePointsEqual(kept.Start, sourceLine.Start))
            {
                return CreateHighlightLine(
                    sourceLine,
                    kept.End,
                    sourceLine.End,
                    tolerance);
            }

            if (tolerance.ArePointsEqual(kept.End, sourceLine.End))
            {
                return CreateHighlightLine(
                    sourceLine,
                    sourceLine.Start,
                    kept.Start,
                    tolerance);
            }
        }

        if (keptLines.Count >= 2)
        {
            LineEntity first = keptLines
                .OrderBy(line => LineParameterService.GetParameter(
                    sourceLine.Geometry,
                    line.Start,
                    tolerance))
                .First();
            LineEntity last = keptLines
                .OrderBy(line => LineParameterService.GetParameter(
                    sourceLine.Geometry,
                    line.End,
                    tolerance))
                .Last();

            return CreateHighlightLine(
                sourceLine,
                first.End,
                last.Start,
                tolerance);
        }

        return Array.Empty<CadEntity>();
    }

    private static IReadOnlyList<CadEntity> CreateHighlightLine(
        LineEntity source,
        Point2D start,
        Point2D end,
        GeometryTolerance tolerance)
    {
        if (start.DistanceTo(end) <= tolerance.Distance)
        {
            return Array.Empty<CadEntity>();
        }

        return new[]
        {
            new LineEntity(
                start,
                end,
                layerId: source.LayerId,
                style: source.Style,
                isVisible: source.IsVisible,
                isLocked: source.IsLocked,
                drawOrder: source.DrawOrder)
        };
    }


    private static EntityId? SelectVisibleEntityByPoint(
        ToolContext context,
        Point2D point)
    {
        BoundingBox2D searchArea = new(
            point.X - context.Selection.Tolerance,
            point.Y - context.Selection.Tolerance,
            point.X + context.Selection.Tolerance,
            point.Y + context.Selection.Tolerance);

        return context.Document.GetVisibleEntities(searchArea)
            .Select(entity => new
            {
                Entity = entity,
                Distance = point.DistanceTo(entity.GetClosestPoint(point))
            })
            .Where(result => result.Distance <= context.Selection.Tolerance)
            .OrderBy(result => result.Distance)
            .ThenByDescending(result => result.Entity.DrawOrder)
            .Select(result => (EntityId?)result.Entity.Id)
            .FirstOrDefault();
    }

    private static EntityId? SelectEntityByPoint(
        ToolContext context,
        Point2D point)
    {
        return context.Selection.Service.SelectByPoint(
            context.Document,
            point,
            context.Selection.Tolerance);
    }


    private static bool IsSupportedEntity(CadEntity entity)
    {
        return entity is LineEntity or CircleEntity or ArcEntity or EllipseEntity or EllipticalArcEntity or PolylineEntity or BezierSplineEntity;
    }

    private void Reset(ToolContext? context = null)
    {
        _boundaryEntityId = null;
        _secondBoundaryEntityId = null;
        _boundaryEntity = null;
        _boundaryEntities.Clear();
        _previewEntities = Array.Empty<CadEntity>();
        _highlightPreviewEntities = Array.Empty<CadEntity>();
        _trimOperationsExecuted = 0;
        _usesAllVisibleCuttingEdges = false;
        State = TrimToolState.WaitingForBoundaryEntity;

        if (context is not null)
        {
            context.CurrentBasePoint = null;
        }
    }
}
